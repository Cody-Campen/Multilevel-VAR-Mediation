the_seed = 196
informative_priors = FALSE
diffuseness = 1
source('main_code.R')
